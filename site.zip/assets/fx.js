(function(){if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;
/* gouttes au toucher / au clic, dans l'élément */
var sel='.btn,.card,a.row,.chip,.wa,button,summary';
document.addEventListener('pointerdown',function(e){var el=e.target.closest&&e.target.closest(sel);if(!el)return;var r=el.getBoundingClientRect(),s=Math.max(r.width,r.height)*2.2,d=document.createElement('span');d.className='rip';d.style.cssText='width:'+s+'px;height:'+s+'px;left:'+(e.clientX-r.left)+'px;top:'+(e.clientY-r.top)+'px';el.appendChild(d);setTimeout(function(){d.remove()},950);if(e.pointerType==='touch'&&navigator.vibrate)try{navigator.vibrate(6)}catch(x){}},{passive:true});
/* eau qui suit la souris (ordinateur seulement) */
if(!matchMedia('(pointer:fine)').matches)return;
var c=document.createElement('canvas');c.id='fx';document.body.appendChild(c);var g=c.getContext('2d'),W,H,dpr=Math.min(devicePixelRatio||1,2);
function sz(){W=innerWidth;H=innerHeight;c.width=W*dpr;c.height=H*dpr;g.setTransform(dpr,0,0,dpr,0,0)}sz();addEventListener('resize',sz);
var mx=-99,my=-99,hx=-99,hy=-99,lx=0,ly=0,lt=0,R=[],run=0,seen=0;
function add(x,y,m,a){R.push({x:x,y:y,r:2,m:m,a:a});if(R.length>40)R.shift()}
addEventListener('pointermove',function(e){if(e.pointerType!=='mouse')return;mx=e.clientX;my=e.clientY;if(!seen){hx=mx;hy=my;seen=1}var t=performance.now(),dx=mx-lx,dy=my-ly;if(dx*dx+dy*dy>420&&t-lt>45){add(mx,my,34,.22);lx=mx;ly=my;lt=t}go()},{passive:true});
addEventListener('pointerdown',function(e){if(e.pointerType!=='mouse')return;add(e.clientX,e.clientY,70,.4);setTimeout(function(){add(e.clientX,e.clientY,110,.22)},110);go()},{passive:true});
document.addEventListener('mouseleave',function(){mx=my=-99;seen=0});
function go(){if(!run){run=1;requestAnimationFrame(f)}}
function f(){g.clearRect(0,0,W,H);hx+=(mx-hx)*.14;hy+=(my-hy)*.14;
if(seen){var gr=g.createRadialGradient(hx,hy,0,hx,hy,26);gr.addColorStop(0,'rgba(0,188,212,.18)');gr.addColorStop(1,'rgba(0,188,212,0)');g.fillStyle=gr;g.beginPath();g.arc(hx,hy,26,0,6.283);g.fill()}
for(var i=R.length-1;i>=0;i--){var p=R[i];p.r+=(p.m-p.r)*.07;var k=1-p.r/p.m;if(k<.02){R.splice(i,1);continue}
g.lineWidth=1.4;g.strokeStyle='rgba(0,188,212,'+(p.a*k).toFixed(3)+')';g.beginPath();g.arc(p.x,p.y,p.r,0,6.283);g.stroke();
g.lineWidth=1;g.strokeStyle='rgba(255,255,255,'+(p.a*k*.9).toFixed(3)+')';g.beginPath();g.arc(p.x,p.y,p.r*.62,0,6.283);g.stroke()}
var moving=Math.abs(mx-hx)+Math.abs(my-hy)>.4;if(R.length||moving){requestAnimationFrame(f)}else{run=0;if(seen){g.clearRect(0,0,W,H);var gr2=g.createRadialGradient(hx,hy,0,hx,hy,26);gr2.addColorStop(0,'rgba(0,188,212,.18)');gr2.addColorStop(1,'rgba(0,188,212,0)');g.fillStyle=gr2;g.beginPath();g.arc(hx,hy,26,0,6.283);g.fill()}}}
})();
